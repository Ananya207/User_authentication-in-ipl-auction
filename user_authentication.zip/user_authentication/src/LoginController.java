public class LoginController {
    private UserModel userModel;
    private LoginView loginView;

    public LoginController(UserModel userModel, LoginView loginView) {
        this.userModel = userModel;
        this.loginView = loginView;
    }

    public void start() {
        // Show the login view
        loginView.setVisible(true);
    }
}
