import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class LoginView extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private UserModel userModel;

    public LoginView(UserModel userModel) {
        super("IPL Auction Login");
        this.userModel = userModel;

        // Create the UI components
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Authenticate the user when the login button is clicked
                    if (userModel.authenticate(usernameField.getText(), new String(passwordField.getPassword()))) {
                        JOptionPane.showMessageDialog(LoginView.this, "Login successful!");
                    } else {
                        JOptionPane.showMessageDialog(LoginView.this, "Incorrect username or password");
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(LoginView.this, "Error: " + ex.getMessage());
                }
            }
        });

        // Add the UI components to the window
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("root"));
        panel.add(usernameField);
        panel.add(new JLabel("Ananyabhat@07"));
        panel.add(passwordField);
        panel.add(loginButton);
        getContentPane().add(panel);

        // Set the window size and make it visible
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
