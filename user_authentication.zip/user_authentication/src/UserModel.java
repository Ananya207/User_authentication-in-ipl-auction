import java.sql.*;

public class UserModel {
    private Connection connection;

    public UserModel() throws SQLException {
        // Connect to the database
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ipl_auction", "root", "Ananyabhat@07");
    }

    public boolean authenticate(String username, String password) throws SQLException {
        // Query the database to check if the user exists and has the correct password
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
        statement.setString(1, username);
        statement.setString(2, password);
        ResultSet result = statement.executeQuery();
        return result.next();
    }
}
